const steps = [
  {
    key:"answer",
    icon:"💌",
    title:"سارا جان، دوست داری با سینا بریم بیرون؟",
    hint:"جوابت رو از ته دل انتخاب کن 😊",
    type:"single",
    options:["😍 آره، با کمال میل","😊 یک وقت دیگه"]
  },
  {
    key:"company",
    icon:"👨‍👩‍👧",
    title:"این دفعه چطوری بریم؟ ❤️",
    hint:"با دختر کوچولو و بامزمون هایلین بریم یا دونفره؟",
    type:"single",
    options:["👨‍👩‍👧 با هایلین بریم","❤️ فقط من و تو"]
  },
  {
    key:"date",
    icon:"📅",
    title:"چه تاریخی برات مناسبه؟",
    hint:"تاریخ دلخواهت رو انتخاب کن.",
    type:"date"
  },
  {
    key:"time",
    icon:"⏰",
    title:"چه ساعتی راحت‌تری؟",
    hint:"ساعتی رو انتخاب کن که عجله نداشته باشی.",
    type:"time"
  },
  {
    key:"city",
    icon:"📍",
    title:"کدوم شهر بریم؟",
    hint:"اسم شهر رو بنویس.",
    type:"text",
    placeholder:"مثلاً برلین"
  },
  {
    key:"activities",
    icon:"✨",
    title:"دوست داری چه کارهایی انجام بدیم؟",
    hint:"می‌تونی چند مورد رو انتخاب کنی.",
    type:"multi",
    options:["🍽️ رستوران","🍦 بستنی","🚶 پیاده‌روی","☕ کافه","🎬 سینما","🌳 پارک","🌅 دیدن غروب","🚗 دور زدن با ماشین","🛍️ خرید","🎳 بولینگ"]
  },
  {
    key:"cuisine",
    icon:"🍽️",
    title:"اگر رستوران رفتیم، چه نوع غذایی دوست داری؟",
    hint:"یک سبک غذا انتخاب کن.",
    type:"single",
    options:["🇮🇷 ایرانی","🇨🇳 چینی","🇹🇷 ترکی","🇦🇫 افغانی","🍕 فرقی نداره"]
  },
  {
    key:"food",
    icon:"🥘",
    title:"حالا کدوم غذا رو انتخاب می‌کنی؟",
    hint:"از منوی همون سبک غذایی یکی رو انتخاب کن.",
    type:"food"
  },
  {
    key:"dessert",
    icon:"🍨",
    title:"بعدش چه دسری بخوریم؟",
    hint:"می‌تونی چند مورد انتخاب کنی.",
    type:"multi",
    options:["🍦 بستنی وانیلی","🍫 بستنی شکلاتی","🍓 بستنی توت‌فرنگی","🍰 کیک","🧇 وافل","☕ قهوه","❌ فعلاً هیچ‌کدوم"]
  }
];

const foodMap = {
  "🇮🇷 ایرانی":["🍢 چلوکباب","🍗 جوجه‌کباب","🍚 زرشک‌پلو با مرغ","🥘 قورمه‌سبزی","🍛 فسنجان","🍲 دیزی"],
  "🇨🇳 چینی":["🍜 نودل","🥟 دامپلینگ","🍚 برنج سرخ‌شده","🍗 مرغ کونگ‌پائو","🥣 سوپ ونتون","🍤 میگو"],
  "🇹🇷 ترکی":["🥙 اسکندر کباب","🍢 آدانا کباب","🥧 پیده","🌮 لاهماجون","🥟 مانتی","🍖 دونر"],
  "🇦🇫 افغانی":["🍚 قابلی پلو","🥟 منتو","🫓 بولانی","🍢 کباب افغانی","🥣 آشک","🍲 شوروا"],
  "🍕 فرقی نداره":["❤️ هرچی سارا دوست داشته باشه"]
};

let current = 0;
const answers = {};

const welcomeStep = document.getElementById("welcomeStep");
const questionStep = document.getElementById("questionStep");
const declineStep = document.getElementById("declineStep");
const finishStep = document.getElementById("finishStep");
const progressWrap = document.getElementById("progressWrap");
const qTitle = document.getElementById("questionTitle");
const qHint = document.getElementById("questionHint");
const qIcon = document.getElementById("questionIcon");
const area = document.getElementById("answersArea");
const nextBtn = document.getElementById("nextBtn");
const backBtn = document.getElementById("backBtn");

document.getElementById("startBtn").onclick = () => {
  welcomeStep.classList.remove("active");
  questionStep.classList.add("active");
  progressWrap.classList.remove("hidden");
  render();
};

function render(){
  const s = steps[current];
  qTitle.textContent = s.title;
  qHint.textContent = s.hint || "";
  qIcon.textContent = s.icon;
  area.innerHTML = "";
  nextBtn.classList.add("hidden");
  backBtn.classList.toggle("hidden", current===0);

  const pct = ((current+1)/steps.length)*100;
  document.getElementById("progressBar").style.width = pct+"%";
  document.getElementById("progressText").textContent = `مرحله ${current+1} از ${steps.length}`;

  if(s.type==="single") renderSingle(s);
  if(s.type==="multi") renderMulti(s);
  if(s.type==="date" || s.type==="time" || s.type==="text") renderInput(s);
  if(s.type==="food") renderFood();
}

function makeOption(text, selected=false){
  const b=document.createElement("button");
  b.className="option"+(selected?" selected":"");
  b.textContent=text;
  return b;
}

function renderSingle(s){
  s.options.forEach(opt=>{
    const b=makeOption(opt, answers[s.key]===opt);
    b.onclick=()=>{
      if(s.key==="answer" && opt.includes("یک وقت")){
        questionStep.classList.remove("active");
        progressWrap.classList.add("hidden");
        declineStep.classList.add("active");
        return;
      }

      answers[s.key]=opt;
      [...area.children].forEach(x=>x.classList.remove("selected"));
      b.classList.add("selected");

      if(s.key==="cuisine"){
        current = steps.findIndex(step => step.key === "food");
        setTimeout(render,180);
        return;
      }

      setTimeout(goNext,180);
    };
    area.appendChild(b);
  });
}

function renderMulti(s){
  const selected = answers[s.key] || [];
  s.options.forEach(opt=>{
    const b=makeOption(opt,selected.includes(opt));
    b.onclick=()=>{
      const list=answers[s.key] || [];
      const i=list.indexOf(opt);
      if(i>=0) list.splice(i,1); else list.push(opt);
      answers[s.key]=list;
      b.classList.toggle("selected");
      nextBtn.classList.toggle("hidden",list.length===0);
    };
    area.appendChild(b);
  });
  nextBtn.classList.toggle("hidden",selected.length===0);
}

function renderInput(s){
  const input=document.createElement("input");
  input.className="field";
  input.type=s.type==="text"?"text":s.type;
  input.placeholder=s.placeholder || "";
  input.value=answers[s.key] || "";
  input.oninput=()=>{
    answers[s.key]=input.value;
    nextBtn.classList.toggle("hidden",!input.value);
  };
  area.appendChild(input);
  nextBtn.classList.toggle("hidden",!input.value);
}

function renderFood(){
  const cuisine=answers.cuisine || "🍕 فرقی نداره";
  const opts=foodMap[cuisine] || foodMap["🍕 فرقی نداره"];
  opts.forEach(opt=>{
    const b=makeOption(opt,answers.food===opt);
    b.onclick=()=>{
      answers.food=opt;
      [...area.children].forEach(x=>x.classList.remove("selected"));
      b.classList.add("selected");
      setTimeout(goNext,180);
    };
    area.appendChild(b);
  });
}

function goNext(){
  if(current < steps.length-1){
    current++;
    render();
  }else{
    finish();
  }
}
nextBtn.onclick=goNext;
backBtn.onclick=()=>{ if(current>0){ current--; render(); } };

function formatDate(v){
  if(!v) return "—";
  try{
    return new Intl.DateTimeFormat("fa-IR",{year:"numeric",month:"long",day:"numeric"}).format(new Date(v+"T12:00:00"));
  }catch{return v}
}

function finish(){
  questionStep.classList.remove("active");
  progressWrap.classList.add("hidden");
  finishStep.classList.add("active");
  const act=(answers.activities||[]).join("، ") || "—";
  const des=(answers.dessert||[]).join("، ") || "—";
  document.getElementById("summary").innerHTML=`
    <div>👨‍👩‍👧 <b>همراه:</b> ${answers.company||"—"}</div>
    <div>📅 <b>تاریخ:</b> ${formatDate(answers.date)}</div>
    <div>⏰ <b>ساعت:</b> ${answers.time||"—"}</div>
    <div>📍 <b>شهر:</b> ${escapeHtml(answers.city||"—")}</div>
    <div>✨ <b>برنامه:</b> ${act}</div>
    <div>🍽️ <b>نوع غذا:</b> ${answers.cuisine||"—"}</div>
    <div>🥘 <b>غذا:</b> ${answers.food||"—"}</div>
    <div>🍨 <b>دسر:</b> ${des}</div>`;
  burst(45);
  localStorage.setItem("saraDateAnswers",JSON.stringify(answers));
}

function escapeHtml(str){
  return str.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}

document.getElementById("loveBtn").onclick=()=>burst(80);

document.getElementById("shareBtn").onclick=async()=>{
  const text=`جواب‌های سارا ❤️
همراه: ${answers.company||"—"}
تاریخ: ${formatDate(answers.date)}
ساعت: ${answers.time||"—"}
شهر: ${answers.city||"—"}
برنامه: ${(answers.activities||[]).join("، ")}
نوع غذا: ${answers.cuisine||"—"}
غذا: ${answers.food||"—"}
دسر: ${(answers.dessert||[]).join("، ")}

با عشق، سینا ❤️`;
  if(navigator.share){
    try{await navigator.share({title:"برنامه قرار سارا و سینا",text});}catch(e){}
  }else{
    await navigator.clipboard.writeText(text);
    alert("خلاصه کپی شد ❤️");
  }
};

function heart(){
  const h=document.createElement("span");
  h.className="floating-heart";
  h.textContent=["❤️","💗","💕","💖"][Math.floor(Math.random()*4)];
  h.style.left=Math.random()*100+"vw";
  h.style.fontSize=(16+Math.random()*22)+"px";
  h.style.animationDuration=(5+Math.random()*5)+"s";
  document.getElementById("hearts").appendChild(h);
  setTimeout(()=>h.remove(),11000);
}
setInterval(heart,650);
function burst(n){for(let i=0;i<n;i++)setTimeout(heart,i*25)}

let taps=0;
document.getElementById("secretHeart").onclick=()=>{
  taps++;
  if(taps>=5){
    document.getElementById("secretMessage").classList.remove("hidden");
    taps=0;
  }
};
document.getElementById("closeSecret").onclick=()=>document.getElementById("secretMessage").classList.add("hidden");
